function tellFortune(kids, partner, location, job){


  document.write("You will be a " + job + " in " + location + " married to " + partner + " with " + kids + " kids.");
  document.write("<br>");

  return;

}

tellFortune(3, "Zoe", "dc", "president");
tellFortune(6, "Brad", "Tel Aviv", "programmer");
tellFortune(4, "Sam", "Berlin", "teacher");
